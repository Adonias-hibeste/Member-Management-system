<?php $__env->startSection('content'); ?>
    <div class="card mb-4">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div><?php echo e($error); ?></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
        <div class="card-header">
            <i class="fas fa-plus"></i> Add Staff
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('admin.staff.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="name" class="form-label">Full Name</label>
                        <input type="text" name="name" value="<?php echo e(old('name')); ?>" class="form-control" required
                            placeholder="Enter full name" />
                    </div>
                    <div class="col-md-6">
                        <label for="gender" class="form-label">Gender</label>
                        <select name="gender" class="form-select" required>
                            <option value="" disabled <?php echo e(old('gender') ? '' : 'selected'); ?>>Select Gender</option>
                            <option value="male" <?php echo e(old('gender') == 'male' ? 'selected' : ''); ?>>Male</option>
                            <option value="female" <?php echo e(old('gender') == 'female' ? 'selected' : ''); ?>>Female</option>
                        </select>
                    </div>
                </div>

                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" name="email" value="<?php echo e(old('email')); ?>" class="form-control" required
                            placeholder="Enter email address" />
                    </div>
                    <div class="col-md-6">
                        <label for="phone_number" class="form-label">Phone Number</label>
                        <input type="tel" class="form-control" name="phone_number" id="phone_number"
                            value="<?php echo e(old('phone_number')); ?>" required placeholder="Enter phone number" />
                    </div>
                </div>

                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="address" class="form-label">Address</label>
                        <input type="text" value="<?php echo e(old('address')); ?>" name="address" class="form-control" required
                            placeholder="Enter address" />
                    </div>
                    <div class="col-md-6">
                        <label for="password" class="form-label">Password</label>
                        <input class="form-control" name="password" type="password" required placeholder="Enter password" />
                    </div>
                </div>

                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="formfile" class="form-label">insert photo</label>
                        <input type="file" value="<?php echo e(old('image')); ?>" name="image" class="form-control" required
                            id="formfile" />
                    </div>

                </div>

                <div class="mb-3">
                    <label for="roles" class="form-label">Assign Roles</label>
                    <div id="roles">
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-check">
                                <input type="checkbox" name="roles[]" value="<?php echo e($role->id); ?>" class="form-check-input"
                                    id="role-<?php echo e($role->id); ?>" />
                                <label for="role-<?php echo e($role->id); ?>" class="form-check-label"><?php echo e($role->name); ?></label>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                <button type="submit" class="btn btn-primary mt-3">Add Staff</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.Adminlayout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FCMS\resources\views/Admin/staff/createStaff.blade.php ENDPATH**/ ?>