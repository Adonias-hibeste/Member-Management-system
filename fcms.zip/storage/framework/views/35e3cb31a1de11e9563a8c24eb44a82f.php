<?php $__env->startSection('content'); ?>
    <div class="container my-5">
        <div class="card">
            <div class="card-header">
                <h2><?php echo e($product->name); ?></h2>
            </div>
            <div class="card-body">
                <div class="row">
                    <!-- Product Images Carousel -->
                    <div class="col-md-6">
                        <?php if($product->images->isNotEmpty()): ?>
                            <div id="productImagesCarousel" class="carousel slide" data-bs-ride="carousel">
                                <div class="carousel-inner">
                                    <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="carousel-item <?php echo e($index === 0 ? 'active' : ''); ?>">
                                            <img src="<?php echo e(asset('uploads/products/' . $image->image)); ?>"
                                                class="d-block w-100" alt="<?php echo e($product->name); ?>">
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <button class="carousel-control-prev" type="button" data-bs-target="#productImagesCarousel"
                                    data-bs-slide="prev">
                                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                    <span class="visually-hidden">Previous</span>
                                </button>
                                <button class="carousel-control-next" type="button" data-bs-target="#productImagesCarousel"
                                    data-bs-slide="next">
                                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                    <span class="visually-hidden">Next</span>
                                </button>
                            </div>
                        <?php else: ?>
                            <img src="<?php echo e(asset('images/no_image_available.png')); ?>" class="img-fluid"
                                alt="No image available">
                        <?php endif; ?>
                    </div>

                    <!-- Product Details -->
                    <div class="col-md-6">
                        <h3>Description</h3>
                        <p><?php echo e($product->description); ?></p>

                        <h4>Category</h4>
                        <p><?php echo e($product->catagory->name); ?></p>

                        <h4>Quantity</h4>
                        <p><?php echo e($product->quantity); ?></p>

                        <h4>Unit Price</h4>
                        <p><?php echo e(number_format($product->unit_price, 2)); ?> birr</p>
                    </div>
                </div>
            </div>

            <!-- Add more details if needed -->
            <div class="card-footer text-end">
                <a href="<?php echo e(route('admin.viewProducts')); ?>" class="btn btn-secondary">Back to Products</a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.Adminlayout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FCMS\resources\views/Admin/products/show.blade.php ENDPATH**/ ?>