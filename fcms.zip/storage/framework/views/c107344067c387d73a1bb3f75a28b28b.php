<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <title>Register</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* Style for the step indicators */
        .step-indicator {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
        }

        .step-indicator .step {
            width: 30%;
            padding: 10px;
            border-radius: 5px;
            text-align: center;
            background-color: #f1f1f1;
        }

        .step-indicator .step.active {
            background-color: #007bff;
            color: white;
        }
    </style>
</head>

<body class="bg-primary">
    <div id="layoutAuthentication">
        <div id="layoutAuthentication_content">
            <main>
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-lg-6">
                            <div class="card shadow-lg border-0 rounded-lg mt-5">
                                <div class="card-header">
                                    <h3 class="text-center font-weight-light my-4">Create Account</h3>
                                </div>
                                <div class="card-body">
                                    <!-- Step Indicator -->
                                    

                                    <form action="<?php echo e(route('admin.registerPost')); ?>" method="POST"
                                        enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>

                                        <div class="step-content">
                                            <?php if($errors->any()): ?>
                                                <div class="alert alert-danger">
                                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div><?php echo e($error); ?></div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                            <?php endif; ?>
                                            <div class="form-floating mb-3">
                                                <input class="form-control" name="full_name" type="text"
                                                    value="<?php echo e(old('full_name')); ?>" required />
                                                <label for="full_name">Full Name</label>
                                            </div>

                                            <div class="form-floating mb-3">
                                                <input class="form-control" name="age" type="number" min="18"
                                                    max="100" value="<?php echo e(old('age')); ?>" required />
                                                <label for="age">Age</label>
                                            </div>
                                            <div class="form-floating mb-3">
                                                <input class="form-control" name="phone_number" type="text"
                                                    value="<?php echo e(old('phone_number')); ?>" required />
                                                <label for="phone_number">Phone Number</label>
                                            </div>
                                            <div class="form-floating mb-3">
                                                <input class="form-control" name="address" type="text"
                                                    value="<?php echo e(old('address')); ?>" required />
                                                <label for="address">Address</label>
                                            </div>
                                            <div class="form-floating mb-3">
                                                <select name="gender" class="form-control" required>
                                                    <option value="male"
                                                        <?php echo e(old('gender') == 'male' ? 'selected' : ''); ?>>Male</option>
                                                    <option value="female"
                                                        <?php echo e(old('gender') == 'female' ? 'selected' : ''); ?>>Female
                                                    </option>
                                                </select>
                                                <label for="gender">Gender</label>
                                            </div>
                                            <div class="form-floating mb-3">
                                                <input class="form-control" name="email" type="email"
                                                    value="<?php echo e(old('email')); ?>" required />
                                                <label for="email">Email</label>
                                            </div>
                                            <div class="form-floating mb-3">
                                                <select name="membership" class="form-control" required>
                                                    <?php $__currentLoopData = $memberships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $membership): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($membership->id); ?>"
                                                            <?php echo e(old('membership') == $membership->id ? 'selected' : ''); ?>>
                                                            <?php echo e($membership->name); ?> / <?php echo e($membership->price); ?> birr
                                                            per month
                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <label for="membership">Choose Membership</label>
                                            </div>
                                        </div>
                                        <div class="form-floating mb-3">
                                            <input class="form-control" name="password" type="password" required />
                                            <label for="password">Password</label>
                                        </div>


                                        <button class="btn btn-success" type="submit">Sign Up</button>
                                </div>
                                </form>

                                <div class="card-footer text-center py-3">
                                    <div class="small"><a href="<?php echo e(route('admin.login')); ?>"> Sign in </a></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
        </div>
        </main>
    </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\FCMS\resources\views/Admin/register.blade.php ENDPATH**/ ?>