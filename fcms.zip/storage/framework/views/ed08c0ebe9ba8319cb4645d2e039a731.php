<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Receipt</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">

</head>

<body class="bg-gray-100 text-gray-900 antialiased min-h-screen flex items-center justify-center">
    <section class="bg-white shadow-lg rounded-lg w-full max-w-3xl p-8">
        <!-- Logo and Title -->
        <div class="flex justify-between items-center mb-6">
            <div class="flex items-center space-x-4">
                <!-- Company Logo -->
                <img src="<?php echo e(asset('uploads/logo/companylogo.png')); ?>" alt="Company Logo"
                    class="w-16 h-16 object-cover">
                <div>
                    <h1 class="text-3xl font-bold uppercase tracking-wide">Receipt</h1>
                    <p class="text-sm text-gray-600">Transaction Ref: <?php echo e($order->tx_ref); ?></p>
                </div>
            </div>
            <!-- Print Button -->
            
        </div>

        <!-- Business & Customer Info -->
        <div class="flex justify-between mb-8">
            <div>
                <h2 class="font-semibold text-lg">From:</h2>
                <p>Test Business</p>
                <p>TIN: Test TIN</p>
                <p>Phone: 0900123456</p>
                <p>Address: Test Address</p>
            </div>
            <div class="text-right">
                <h2 class="font-semibold text-lg">To:</h2>
                <p><?php echo e($order->user->full_name); ?></p>
                <p>Email: <?php echo e($order->user->email); ?></p>
                <p>Phone: <?php echo e($order->orderDetail->phone); ?></p>
                <p>Address: <?php echo e($order->orderDetail->city); ?>,Woreda: <?php echo e($order->orderDetail->woreda); ?>, House No:
                    <?php echo e($order->orderDetail->house_no); ?></p>
            </div>
        </div>

        <!-- Order Summary -->
        <div class="border-t border-gray-300 pt-4 mb-6">
            <h3 class="text-xl font-semibold mb-3">Order Summary</h3>
            <table class="w-full text-left text-sm">
                <thead>
                    <tr class="text-gray-600 border-b">
                        <th class="pb-2">Product</th>
                        <th class="pb-2 text-right">Quantity</th>
                        <th class="pb-2 text-right">Price</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $order->order_item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->product->name); ?></td>
                            <td class="text-right"><?php echo e($item->quantity); ?></td>
                            <td class="text-right"><?php echo e($item->price); ?> ETB</td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <!-- Payment Details -->
        <div class="border-t border-gray-300 pt-4">
            <h3 class="text-xl font-semibold mb-3">Payment Details</h3>
            <p><strong>Status:</strong> <?php echo e($order->payment_status); ?></p>
            <p><strong>Payment Date:</strong> <?php echo e($order->order_date); ?></p>
            <p><strong>Total Amount Paid:</strong> <?php echo e($order->total_amount); ?> ETB</p>
        </div>

        <!-- Footer -->
        <footer class="mt-8 text-center text-sm text-gray-500">
            <p>Thank you for choosing Test Business!</p>
        </footer>
    </section>

    <script>
        function printReceipt() {
            window.print();
        }
    </script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\FCMS\resources\views/Admin/reciept/orderReciept.blade.php ENDPATH**/ ?>