<?php $__env->startSection('content'); ?>
    <div class="container-fluid px-4">
        <div class="card mt-4">
            <div class="card-header">
                <h4>Order Details - #<?php echo e($order->id); ?></h4>
            </div>
            <div class="card-body">
                <p><strong>Ordered by:</strong>
                    <?php if($order->user): ?>
                        <?php echo e($order->user->full_name); ?>

                    <?php else: ?>
                        <span class="text-danger">User not found</span>
                    <?php endif; ?>
                </p>
                <p><strong>Order Date:</strong> <?php echo e($order->order_date); ?></p>
                <p><strong>Payment Status:</strong> <?php echo e($order->payment_status); ?></p>
                <p><strong>Total Amount:</strong> <?php echo e($order->total_amount); ?> birr</p>

                <h5>Order Items:</h5>
                <?php if($order->order_item->count() > 0): ?>
                    <table class="table table-bordered table-hover">
                        <thead style="background-color: #343a40; color: white;">
                            <tr>
                                <th>Product Name</th>
                                <th>Quantity</th>
                                <th>Price</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $order->order_item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <?php if($item->product): ?>
                                            <?php echo e($item->product->name); ?>

                                        <?php else: ?>
                                            <span class="text-danger">Product not found</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($item->quantity); ?></td>
                                    <td><?php echo e($item->price); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p>No items available in this order.</p>
                <?php endif; ?>

                <a href="<?php echo e(route('admin.order.view')); ?>" class="btn btn-primary">Back to Orders</a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.Adminlayout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FCMS\resources\views/Admin/order/show.blade.php ENDPATH**/ ?>