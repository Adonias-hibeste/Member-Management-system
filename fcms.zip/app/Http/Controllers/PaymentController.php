<?php

namespace App\Http\Controllers;

use App\Models\MembershipPayment;
use Illuminate\Http\Request;
use App\Models\Payment;
use App\Models\Profile;
use GuzzleHttp\Client;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class PaymentController extends Controller
{
    public function index()
    {

        $user = Auth::user();
        $profile = Profile::with('membership')->where('user_id', $user->id)->first();

        // Check if profile exists
        if ($profile) {
            return view('User.membership_payment.index', [
                'profile' => $profile,
                'amount' => $profile->membership->price, // Get the price from the membership
            ]);
        }

        // Handle case where profile does not exist (optional)
        return redirect()->back()->with('error', 'Profile not found.');
    }

    public function processPayment(Request $request)
    {
        $client = new Client();

        $tx_ref = 'TX_' . uniqid();

        // Store tx_ref in session for later use in callback
        session(['tx_ref' => $tx_ref]);

        // Chapa API endpoint for initiating payment
        $url = 'https://api.chapa.co/v1/transaction/initialize';
        // Chapa secret key
        $chapaSecretKey = env('CHAPA_SECRET_KEY');

        // Prepare the data for Chapa API
        $data = [
            'amount' => $request->input('amount'),
            'currency' => 'ETB',
            'email' => $request->user()->email, // Assuming the user is authenticated
            'first_name' => $request->user()->full_name,
            'tx_ref' => $tx_ref,
            'callback_url' => route('user.membershipPayment.callback'),
            //'return_url' => route('payment.return'),
            'customization' => [
                    'title' => 'Payment',
                    'description' => 'Service payment description',
                ],
        ];


        $response = Http::withToken($chapaSecretKey)->post('https://api.chapa.co/v1/transaction/initialize', $data);

        $response = $client->post($url, [
            'headers' => [
                'Authorization' => 'Bearer ' . 'CHASECK_TEST-apCgo8j5B4cpFmtlgV1NOAgpqp3PksVz',
                'Content-Type' => 'application/json',
            ],
            'json' => $data,
        ]);

        // Handle the response
        $responseBody = json_decode($response->getBody(), true);

        if ($responseBody['status'] === 'success') {
            return redirect($responseBody['data']['checkout_url']); // Redirect to the payment page
        } else {
            return redirect()->back()->with('error', 'Payment initiation failed.');
        }
    }

    public function paymentCallback(Request $request)
    {

        $tx_ref = session('tx_ref');

        if (!$tx_ref) {
            return redirect()->route('user.membership.payment')->with('error', 'Transaction reference missing.');
        }

        Log::info('Callback triggered', ['request' => $request->all()]);

        $tx_ref = $request->input('tx_ref');

        $response = Http::withToken(env('CHAPA_SECRET_KEY'))->get('https://api.chapa.co/v1/transaction/verify/' . $tx_ref);

        if ($response->successful()) {
            $paymentData = $response->json();

            if ($paymentData['status'] == 'success') {

                $user = Auth::user();
                $profile = $user->profile;


                $profile->member_payment_status = 'paid';
                $profile->membership_endDate = now()->addMonth(); // Example: one year membership
                $profile->save();

                // Optionally, store the payment details
                $this->storePaymentDetails($paymentData, $user->id);
                Log::info('Payment successful, updating user data');

                return redirect()->route('user.membership.payment')->with('message','payment sucessfull');

            }
            session()->forget('tx_ref');

        }
        else {
            Log::error('Payment verification failed', ['response' => $response->body()]);
            return redirect()->route('user.membership.payment')->with('error', 'Payment verification failed.');
        }



    }

    private function storePaymentDetails($paymentData, $userId)
{
    // Create a new payment record (assuming you have a MembershipPayment model)
   MembershipPayment::create([
        'user_id' => $userId,
        'tx_ref' => $paymentData['data']['tx_ref'],
        'amount' => $paymentData['data']['amount'],
        'status' => $paymentData['status'],
        'payment_method' => $paymentData['data']['payment_method'],
        'transaction_id' => $paymentData['data']['transaction_id'],
        'payment_date' => now(),
    ]);
}

}
