<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="payment-form">
            <h2>Payment Form</h2>
            

            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div><?php echo e($error); ?></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>

            <?php if(session('message')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('message')); ?>

                </div>
            <?php endif; ?>
            <form action="<?php echo e(route('user.payment.process')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label for="memberName" class="form-label">Member Name</label>
                    <input type="text" class="form-control" id="memberName" name="memberName"
                        value="<?php echo e($profile->user->full_name); ?>" required readonly>
                </div>
                <div class="mb-3">
                    <label for="membershipType" class="form-label">Membership Type</label>
                    <input type="text" class="form-control" id="membershipType" name="membershipType"
                        value="<?php echo e($profile->membership->name); ?>" required readonly>
                </div>

                <div class="mb-3">
                    <label for="amount" class="form-label">Amount to Pay</label>
                    <input type="number" class="form-control" id="amount" name="amount" value="<?php echo e($amount); ?>"
                        required readonly>
                </div>
                <button type="submit" class="btn btn-primary btn-block">Proceed to Pay</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('User.UserLayout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Member-Management-system\resources\views\User\membership_payment\index.blade.php ENDPATH**/ ?>