<?php $__env->startSection('content'); ?>
    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-plus"></i> Edit membership
        </div>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div><?php echo e($error); ?></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
        <div class="card-body">
            <form action="<?php echo e(route('admin.membership.edit', $membership->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="my-2">
                    <div class="col-12 col-md-6">
                        <label for="membership">MemberShip Name</label>
                        <input type="text" name="membership_name" value="<?php echo e($membership->name); ?>" class="form-control">
                    </div>

                </div>

                <div class="form-group mb-3">
                    <label for="price">price</label>
                    <input type="text" name="price" class="form-control" value="<?php echo e($membership->price); ?>">
                </div>





                <button type="submit" class="btn btn-primary mt-3">Edit membership</button>
            </form>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.Adminlayout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Member-Management-system\resources\views\Admin\membership\edit.blade.php ENDPATH**/ ?>