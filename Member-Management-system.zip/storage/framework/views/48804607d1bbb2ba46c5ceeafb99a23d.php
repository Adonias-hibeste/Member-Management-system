<?php $__env->startSection('content'); ?>
    <div class="container-fluid px-4">
        <div class="card shadow mt-4">
            <h2 class="mb-0">Order Details - #<?php echo e($order->id); ?></h2>

            <div class="card-body">
                <!-- Order Info -->
                <div class="mb-6">
                    <h5 class="text-muted">Order Information</h5>
                    <hr>
                    <p><strong>Ordered by:</strong>
                        <?php if($order->user): ?>
                            <span class="badge bg-success"><?php echo e($order->user->full_name); ?></span>
                        <?php else: ?>
                            <span class="badge bg-danger">User not found</span>
                        <?php endif; ?>
                    </p>
                    <p><strong>Order Date:</strong> <span class="text-muted"><?php echo e($order->order_date); ?></span></p>
                    <p><strong>Payment Status:</strong>
                        <?php if($order->payment_status == 'Paid'): ?>
                            <span class="badge bg-success">Paid</span>
                        <?php else: ?>
                            <span class="badge bg-warning">Pending</span>
                        <?php endif; ?>
                    </p>
                    <p><strong>Total Amount:</strong> <span class="text-muted"><?php echo e($order->total_amount); ?> birr</span></p>
                </div>

                <!-- Order Items -->
                <div class="mb-4">
                    <h5 class="text-muted">Order Items</h5>
                    <hr>
                    <?php if($order->order_item->count() > 0): ?>
                        <table class="table table-bordered table-hover">
                            <thead class="bg-dark text-white">
                                <tr>
                                    <th>Product Name</th>
                                    <th class="text-center">Quantity</th>
                                    <th class="text-right">Price (ETB)</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $order->order_item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <?php if($item->product): ?>
                                                <?php echo e($item->product->name); ?>

                                            <?php else: ?>
                                                <span class="text-danger">Product not found</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-center"><?php echo e($item->quantity); ?></td>
                                        <td class="text-right"><?php echo e($item->price); ?> birr</td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <p class="text-warning">No items available in this order.</p>
                    <?php endif; ?>
                </div>

                <!-- Show Receipt Button -->
                <button class="btn btn-secondary" data-bs-toggle="modal" data-bs-target="#receiptModal">
                    Show Receipt
                </button>
                <a href="<?php echo e(route('admin.order.view')); ?>" class="btn btn-primary">Back to Orders</a>
            </div>
        </div>
    </div>

    <!-- Receipt Modal -->
    <div class="modal fade" id="receiptModal" tabindex="-1" aria-labelledby="receiptModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="receiptModalLabel">Order Receipt - #<?php echo e($order->id); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <?php echo $__env->make('Admin.reciept.orderReciept', ['order' => $order], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button onclick="window.print()" class="btn btn-primary">Print Receipt</button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.Adminlayout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Member-Management-system\resources\views\Admin\order\show.blade.php ENDPATH**/ ?>