<?php $__env->startSection('content'); ?>

    <div class="card mb-4">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div><?php echo e($error); ?></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
        <div class="card-header">
            <i class="fas fa-plus"></i> Add Role
        </div>
        <div class="card-body">
            <form action="" method="POST">
                <?php echo csrf_field(); ?>

                <div class="my-2">
                    <div class="col-12 col-md-6">
                        <label for="name">Role Name</label>
                        <input type="text" name="role_name" class="form-control">
                    </div>

                </div>

                <div>
                    <label for="permission">Choose Permission </label>
                </div>
                <div class="form-check">
                    <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div>
                            <input type="checkbox" name="permissions[]" value="<?php echo e($permission->name); ?>"
                                class="form-check-input" id="permission-<?php echo e($permission->id); ?>">
                            <label for="permission-<?php echo e($permission->id); ?>"
                                class="form-check-label"><?php echo e($permission->name); ?></label>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>


                <button type="submit" class="btn btn-primary mt-3">Add Role</button>
            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.Adminlayout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Member-Management-system\resources\views\Admin\Role\edit.blade.php ENDPATH**/ ?>